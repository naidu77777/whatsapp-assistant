import pywhatkit
import json
import time
import pyautogui

def send_message(contact_name, message):
    try:
        with open("contacts.json", "r") as f:
            contacts = json.load(f)

        number = contacts.get(contact_name.lower())
        if not number:
            print(f"❌ Contact '{contact_name}' not found.")
            return

        print(f"✅ Sending '{message}' to {contact_name} ({number})...")
        pywhatkit.sendwhatmsg_instantly(number, message, wait_time=10)

        time.sleep(10)  # Wait for WhatsApp Web to load and message to be typed
        pyautogui.press("enter")  # Automatically press Enter key
        print("✅ Message sent successfully!")

    except Exception as e:
        print(f"⚠️ Error: {e}")

from voice_input import get_voice_command
from intent_parser import parse_command
#from messenger import send_pywhatkit  # or send_gui
from whatsapp_sender import send_pywhatkit


def main():
    command = get_voice_command()
    if not command:
        return

    contact, message = parse_command(command)
    if contact and message:
        send_pywhatkit.send_message(contact, message)
    else:
        print("❌ Command parsing failed. Please try again.")

if __name__ == "__main__":
    main()

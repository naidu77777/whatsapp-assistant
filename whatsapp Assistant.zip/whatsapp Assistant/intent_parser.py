import re

def parse_command(command):
    # Example: "open jana chat and send hi message"
    match = re.search(r'open (\w+) chat.*send (.+?) message', command)
    if match:
        contact = match.group(1).strip()
        message = match.group(2).strip()
        return contact, message
    return None, None
